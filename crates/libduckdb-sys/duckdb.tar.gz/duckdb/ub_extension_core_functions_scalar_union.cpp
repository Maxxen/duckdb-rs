#include "extension/core_functions/scalar/union/union_extract.cpp"

#include "extension/core_functions/scalar/union/union_value.cpp"

#include "extension/core_functions/scalar/union/union_tag.cpp"

