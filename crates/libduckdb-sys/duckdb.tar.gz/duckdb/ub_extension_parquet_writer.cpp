#include "extension/parquet/writer/array_column_writer.cpp"

#include "extension/parquet/writer/boolean_column_writer.cpp"

#include "extension/parquet/writer/decimal_column_writer.cpp"

#include "extension/parquet/writer/enum_column_writer.cpp"

#include "extension/parquet/writer/list_column_writer.cpp"

#include "extension/parquet/writer/primitive_column_writer.cpp"

#include "extension/parquet/writer/struct_column_writer.cpp"

