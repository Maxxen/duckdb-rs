#include "src/execution/operator/scan/physical_column_data_scan.cpp"

#include "src/execution/operator/scan/physical_dummy_scan.cpp"

#include "src/execution/operator/scan/physical_empty_result.cpp"

#include "src/execution/operator/scan/physical_expression_scan.cpp"

#include "src/execution/operator/scan/physical_positional_scan.cpp"

#include "src/execution/operator/scan/physical_table_scan.cpp"

